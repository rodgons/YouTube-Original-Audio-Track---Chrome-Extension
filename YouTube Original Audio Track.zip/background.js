chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed and ready to fix YouTube audio tracks!");
});
